// ejercicio5. Imprimir los cuadrados de los enteros de 1 a 20.

for (let i = 1; i <=20; i++){
    console.log("el cuadrado de" +i +" es igual a: " +Math.pow(i,2));
}