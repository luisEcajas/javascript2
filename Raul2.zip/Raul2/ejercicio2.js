// Ejercicio2.Imprimir las treinta primeras potencias de 4, es decir, 4 elevado a 1, 4 elevado a 2, etc.

for (let i=1; i<=30; i++){
    console.log("4 elevado a" +i +"igual a:" +Math.pow(4,i));
}

