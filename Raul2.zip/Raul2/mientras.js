var vuelta = 0;

while (vuelta<100){
    console.log("Vuelta numero: " + vuelta);
}

let dato = false;

do{
    console.log("al menos una vez");
} while (dato);

for (let vuelta=0; vuelta<100;vuelta++){
    console.log("Vuelta numero: " + vuelta);
}

