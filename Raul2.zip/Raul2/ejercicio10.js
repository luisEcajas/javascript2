// ejercicio10. Diseñar un programa que produzca la siguiente salida:
//ZYXWVTSRQPONMLKJIHGFEDCBA
//YXWVTSRQPONMLKJIHGFEDCBA
//XWVTSRQPONMLKJIHGFEDCBA
//WVTSRQPONMLKJIHGFEDCBA
//VTSRQPONMLKJIHGFEDCBA
//...
//FEDCBA
//EDCBA
//DCBA
//CBA
//BA
//A

// 1. Definimos el abecedario completo de la Z a la A
let alfabeto = "ZYXWVTSRQPONMLKJIHGFEDCBA";

// 2. Usamos un bucle para determinar en qué letra comienza cada fila
// Recorremos desde la posición 0 hasta la última letra
for (let i = 0; i < alfabeto.length; i++) {
    
    let fila = "";
    
    // 3. Este segundo bucle construye la fila tomando las letras 
    // desde la posición 'i' hasta el final de la cadena
    for (let j = i; j < alfabeto.length; j++) {
        fila = fila + alfabeto[j];
    }
    
    // 4. Imprimimos la fila resultante
    console.log(fila);
}