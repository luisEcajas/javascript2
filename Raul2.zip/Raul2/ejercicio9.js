// ejercicio 9. Diseñar un algoritmo que sume los m = 30 primeros números pares.

let m= 30;
let suma = 0;

for (let i = 0; i < m; i++){
    suma += 2 * i;
    

}
console.log("la suuma de los "+ m + " primeros numeros pares es: " + suma);