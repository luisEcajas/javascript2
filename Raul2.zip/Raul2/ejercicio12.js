//Elabore un algoritmo, que genere e imprima las letras del abecedario de la siguiente forma:

// 1. Definimos la cadena con el abecedario de la Z a la A
let alfabeto = "ZYXWVTSRQPONMLKJIHGFEDCBA";

// 2. Bucle externo: Controla cuántas letras se imprimen en cada fila
// Empezamos en 0 (solo la Z) y llegamos hasta el final de la cadena
for (let i = 0; i < alfabeto.length; i++) {
    
    let fila = "";
    
    // 3. Bucle interno: Siempre empieza en la posición 0 (la Z)
    // y llega hasta la posición indicada por 'i'
    for (let j = 0; j <= i; j++) {
        fila = fila + alfabeto[j] + " ";
    }
    
    // 4. Imprimimos la fila construida
    console.log(fila);
}
