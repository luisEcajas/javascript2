// Do while.Esta estructura garantiza que el código se ejecute al menos una vez antes de revisar la condición.
let suma = 0;
let i = 1;

do {
    suma += i;
    i++;
} while (i <= 100);

console.log("Resultado con do-while:", suma);

// While. Aquí la condición se revisa antes de entrar al bloque. Si la condición fuera falsa desde el inicio, 
// el código nunca se ejecutaría.

let suma2 = 0;
let i2 = 1;

while (i2 <= 100) {
    suma2 += i2;
    i2++;
}

console.log("Resultado con while:", suma2);

// For. Es la forma más compacta y común cuando sabemos exactamente cuántas veces queremos repetir algo. 
// Todo está en una sola línea (inicialización, condición e incremento).

let suma3 = 0;

for (let i = 1; i <= 100; i++) {
    suma3 += i;
}

console.log("Resultado con for:", suma3);