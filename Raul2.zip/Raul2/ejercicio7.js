// ejercicio 7. Escribir un programa que visualice la siguiente salida:
//1
//1 2
//1 2 3
//1 2 3 4
//1 2 3
//1 2
//1

let maxNumeros =4;

maxAsteriscos=5;
for (let i = 1; i <= maxAsteriscos; i += 1) {
    let fila = "";
    
    // Bucle para añadir los asteriscos
    for (let k = 0; k < i; k++) {
        fila += (k + 1) + " ";
    }
    
    console.log(fila);
}
for (let i = maxAsteriscos - 1; i >= 1; i -= 1) {
    let fila = "";
    
    // Bucle para añadir los asteriscos
    for (let k = 0; k < i; k++) {
        fila += (k + 1) + " ";
    }
    
    console.log(fila);
}

