let maxAsteriscos = 9;

// 1. PARTE SUPERIOR (Creciente)
for (let i = 1; i <= maxAsteriscos; i += 2) {
    let fila = "";
    
    // Bucle para añadir espacios a la izquierda
    let numEspacios = (maxAsteriscos - i) / 2;
    for (let j = 0; j < numEspacios; j++) {
        fila += " ";
    }
    
    // Bucle para añadir los asteriscos
    for (let k = 0; k < i; k++) {
        fila += "*";
    }
    
    console.log(fila);
}

// 2. PARTE INFERIOR (Decreciente)
for (let i = maxAsteriscos - 2; i >= 1; i -= 2) {
    let fila = "";
    
    // Bucle para los espacios
    let numEspacios = (maxAsteriscos - i) / 2;
    for (let j = 0; j < numEspacios; j++) {
        fila += " ";
    }
    
    // Bucle para los asteriscos
    for (let k = 0; k < i; k++) {
        fila += "*";
    }
    
    console.log(fila);
}
