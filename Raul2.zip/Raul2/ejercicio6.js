// ejercicio6. Visualizar en pantalla una figura similar a la siguiente:

//*

//**

//***

//****

//*****

maxAsteriscos=5;
for (let i = 1; i <= maxAsteriscos; i += 1) {
    let fila = "";
    
    // Bucle para añadir los asteriscos
    for (let k = 0; k < i; k++) {
        fila += "*";
    }
    
    console.log(fila);
}

