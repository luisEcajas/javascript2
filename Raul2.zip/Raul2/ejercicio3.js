//ejercicio3. Imprimir todos los números primos entre 2 y 1.000 inclusive.

// Bucle externo: recorre los números del 2 al 1000
for (let n = 2; n <= 1000; n++) {
    
    let esPrimo = true; // Suponemos que es primo hasta que se demuestre lo contrario

    // Bucle interno
    for (let i = 2; i < n; i++) {
        if (n % i === 0) {
            esPrimo = false; // Si el residuo es 0, encontramos un divisor
            break;           // Nos salimos del bucle interno, ya no es primo
        }
    }

    
    if (esPrimo) {
        console.log(n);
    }
}
