//Ejercicio8.Diseñar e implementar un programa que solicite a su usuario un valor no 
// negativo n y visualice la siguiente salida (n = 6):

//1 2 3 4 5 6
//1 2 3 4 5
//1 2 3 4
//1 2 3
//1 2
//1

let maxNumeros =6;

for (let i = maxNumeros; i >=1; i-=1){
    let fila ="";
    for (let k = 0; k < i; k++){
        fila += (k + 1) + " ";
    }
    console.log(fila);
}
