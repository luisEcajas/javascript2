let n = 20; // Puedes cambiar este valor para probar

if (n <= 6) {
    console.log("Error: El valor de n debe ser superior a 6.");
} else {
    console.log(`Múltiplos de 3 entre 6 y ${n}:`); // el $ es una forma mas resumida de concatenacion
    
    // Usamos un bucle for para recorrer el rango
    for (let i = 6; i <= n; i++) {
        // Verificamos si el número es múltiplo de 3 usando el operador residuo (%)
        if (i % 3 === 0) {
            console.log(i);
        }
    }
}